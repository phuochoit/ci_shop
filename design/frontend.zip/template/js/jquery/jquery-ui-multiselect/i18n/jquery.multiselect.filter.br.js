/* Brazilian initialisation for the jQuery UI multiselect plugin. */
/* Written by Vinícius Fontoura Corrêa (vinusfc@gmail.com). */

(function ( $ ) {

$.extend($.ech.multiselectfilter.prototype.options, {
	label: "Filtro:",
	placeholder: "Entre com a palavra"
});

})( jQuery );
